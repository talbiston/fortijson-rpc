from distutils.core import setup
setup(
  name = 'FortiJson',         
  packages = ['FortiJson'],   
  version = '0.1',      
  license='MIT',        
  description = 'Json formating tool that conforms to Fortinets Json RPC protocol',
  author = 'Todd Albiston',                   
  author_email = 'foxtrot711@gmail.com',      
  url = 'https://github.com/talbiston/fortijson-rpc',   
  download_url = 'https://github.com/user/reponame/archive/v_01.tar.gz',    # I explain this later on
  keywords = ['Fortigate', 'Fortinet', 'Fortinet api'],   
  install_requires=[            
          'json', 
          'collections', 
          'requests', 
      ],
  classifiers=[
    'Development Status :: 3 - Alpha',      # Chose either "3 - Alpha", "4 - Beta" or "5 - Production/Stable" as the current state of your package
    'Intended Audience :: Developers',      # Define that your audience are developers
    'Topic :: Software Development :: Build Tools',
    'License :: OSI Approved :: MIT License',   # Again, pick a license
    'Programming Language :: Python :: 3',      #Specify which pyhton versions that you want to support
    'Programming Language :: Python :: 3.4',
    'Programming Language :: Python :: 3.5',
    'Programming Language :: Python :: 3.6',
  ],
)